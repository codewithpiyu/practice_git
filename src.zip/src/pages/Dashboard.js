import React from 'react'


const Dashboard = (props) => {
  return (
    <div>
      <h1>{props.title}</h1>
   
    </div>
    
  )
}
export default  Dashboard;
