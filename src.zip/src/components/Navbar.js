function Navbar() {
    return (
      <div class="">
        <input type = "text"  name="searchbox"/>
        hello
          

      </div>
    )
  }
  export default Navbar;